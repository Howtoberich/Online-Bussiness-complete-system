# Proof Tokensale Dashboard

{{TOC}}

# How to change constants
directory location: ./src/utility/constants/base-constants.ts

# How to add or modify Languages

directory location of Translation Text: 
/src/app/utility/translate

Basefile: lang.en.ts



# Locations

