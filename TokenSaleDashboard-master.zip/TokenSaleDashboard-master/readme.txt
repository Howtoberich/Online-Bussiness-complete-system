=> Toast message
  - https://www.npmjs.com/package/ng2-toastr
  - npm install ng2-toastr --save

=> SASS run
  - sass --watch TokenSale.scss:TokenSale.css

==> Material Icon
  - https://material.io/icons
  - https://semantic-ui.com/elements/icon.html

==> Animation
  - npm install --save @angular/animations

==> Country Dropdown
   - https://github.com/mrmarkfrench/country-select-js#demo

==> Canvas Demo
   - https://github.com/VincentGarreau/particles.js/#demo--generator

