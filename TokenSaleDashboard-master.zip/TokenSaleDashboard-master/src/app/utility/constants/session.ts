export class KSESSION {
  public static SELECTED_CUSTOMER: string = "su";
}
