export class APPStorage {
  public static TOKEN = 'at';
  public static USER = 'u';
  static PASS='p';
  static REFER='r';
  static LANG='lg';
}
