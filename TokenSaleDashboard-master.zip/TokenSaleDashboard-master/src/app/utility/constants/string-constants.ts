export class COMMON_STR {
  public static LOADING = 'Loading Data...';
}
