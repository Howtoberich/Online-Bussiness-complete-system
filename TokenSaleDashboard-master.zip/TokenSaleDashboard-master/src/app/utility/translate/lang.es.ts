// lang-es.ts

export const LANG_ES_NAME = 'es';

export const LANG_ES_TRANS = {
  'Welcome to app!' : 'Bienvenido a la aplicación!',
};
